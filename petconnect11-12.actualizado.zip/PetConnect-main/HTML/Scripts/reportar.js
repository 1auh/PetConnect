import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, query, where } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const reportForm = document.getElementById("report-form");
const reportsList = document.getElementById("reports-list");
const successMessage = document.getElementById("report-success-message");
const errorMessage = document.getElementById("report-error-message");

// Crear un nuevo reporte
reportForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const user = auth.currentUser;

    if (!user) {
        alert("Debes iniciar sesión para reportar una mascota.");
        return;
    }

    const name = document.getElementById("report-name").value;
    const description = document.getElementById("report-description").value;
    const zone = document.getElementById("report-zone").value;
    const contact = document.getElementById("report-contact").value;

    try {
        await addDoc(collection(db, "reports"), {
            name,
            description,
            zone,
            contact,
            uid: user.uid, // Asociar reporte con el usuario actual
        });

        successMessage.style.display = "block";
        errorMessage.style.display = "none";
        reportForm.reset();
        loadReports(); // Recargar los reportes después de crear uno nuevo
    } catch (error) {
        console.error("Error al crear el reporte:", error);
        successMessage.style.display = "none";
        errorMessage.style.display = "block";
        errorMessage.textContent = "Ocurrió un error al crear el reporte. Intenta nuevamente.";
    }
});

// Cargar los reportes del usuario actual
async function loadReports() {
    reportsList.innerHTML = ""; // Limpiar la lista antes de recargar
    const user = auth.currentUser;

    if (!user) {
        alert("Debes iniciar sesión para ver tus reportes.");
        return;
    }

    const q = query(collection(db, "reports"), where("uid", "==", user.uid)); // Filtrar por UID del usuario
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
        reportsList.innerHTML = "<p>No tienes reportes aún.</p>";
        return;
    }

    querySnapshot.forEach((docSnap) => {
        const report = docSnap.data();
        const reportId = docSnap.id;

        const reportCard = document.createElement("div");
        reportCard.className = "report-card";

        reportCard.innerHTML = `
            <h3>${report.name}</h3>
            <p><strong>Descripción:</strong> ${report.description}</p>
            <p><strong>Zona:</strong> ${report.zone}</p>
            <p><strong>Contacto:</strong> ${report.contact}</p>
            <button class="form-button delete-report-button" data-id="${reportId}">Eliminar</button>
        `;

        reportsList.appendChild(reportCard);
    });

    attachDeleteEvents(); // Asociar eventos para eliminar
}

// Eliminar un reporte
function attachDeleteEvents() {
    const deleteButtons = document.querySelectorAll(".delete-report-button");
    deleteButtons.forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const id = e.target.dataset.id;
            try {
                await deleteDoc(doc(db, "reports", id));
                loadReports(); // Recargar la lista después de eliminar
            } catch (error) {
                console.error("Error al eliminar el reporte:", error);
            }
        });
    });
}

// Escuchar cambios en el estado de autenticación
onAuthStateChanged(auth, (user) => {
    if (user) {
        loadReports(); // Cargar reportes cuando el usuario está autenticado
    } else {
        reportsList.innerHTML = "<p>Inicia sesión para ver tus reportes.</p>";
    }
});
