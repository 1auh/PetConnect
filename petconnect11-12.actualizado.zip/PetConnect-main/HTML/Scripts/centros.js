import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, collection, addDoc, getDocs, getDoc, deleteDoc, doc, updateDoc } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-storage.js';


// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const centersList = document.getElementById("centers-list");
const form = document.getElementById("create-center-form");
const successMessage = document.getElementById("success-message");
const errorMessage = document.getElementById("error-message");
const petsContainer = document.getElementById("pets-container");
const addPetButton = document.getElementById("add-pet");

// Referencias para el modal de edición
const editModal = document.getElementById("edit-modal");
const closeModal = document.getElementById("close-modal");
const editForm = document.getElementById("edit-center-form");
const editPetsContainer = document.getElementById("edit-pets-container");

const storage = getStorage(app);

// Agregar mascotas dinámicamente en el formulario principal
addPetButton.addEventListener("click", () => {
    const petForm = document.createElement("div");
    petForm.className = "pet-form";

    petForm.innerHTML = `
        <label class="form-label">Nombre de la Mascota:</label>
        <input type="text" class="form-input pet-name" placeholder="Ej. Fido" required>

        <label class="form-label">Descripción:</label>
        <textarea class="form-textarea pet-description" placeholder="Descripción de la mascota" rows="2"></textarea>

        <label class="form-label">Foto de la Mascota:</label>
        <input type="file" class="form-input pet-photo" accept="image/*">

        <button type="button" class="form-button delete-pet">Eliminar Mascota</button>
    `;

    petsContainer.appendChild(petForm);

    // Agregar funcionalidad para eliminar mascota
    petForm.querySelector(".delete-pet").addEventListener("click", () => {
        petsContainer.removeChild(petForm);
    });
});


// Manejo del formulario para crear centros
form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const location = document.getElementById("location").value;
    const contact = document.getElementById("contact").value;
    const description = document.getElementById("description").value;

    const pets = [];
    const petForms = document.querySelectorAll(".pet-form");

    try {
        // Subir fotos y recolectar datos de mascotas
        for (const petForm of petForms) {
            const petName = petForm.querySelector(".pet-name").value;
            const petDescription = petForm.querySelector(".pet-description").value;
            const petPhoto = petForm.querySelector(".pet-photo").files[0];

            let photoURL = null;
            if (petPhoto) {
                const photoRef = ref(storage, `pets/${Date.now()}_${petPhoto.name}`);
                await uploadBytes(photoRef, petPhoto);
                photoURL = await getDownloadURL(photoRef);
            }

            pets.push({ name: petName, description: petDescription, photo: photoURL });
        }

        // Crear el documento del centro
        await addDoc(collection(db, "centers"), {
            name,
            location,
            contact,
            description,
            pets,
        });

        successMessage.style.display = "block";
        errorMessage.style.display = "none";
        form.reset();
        petsContainer.innerHTML = `<h3>Mascotas Disponibles</h3><button type="button" id="add-pet" class="form-button">Agregar Mascota</button>`;
        loadCenters();
    } catch (error) {
        console.error("Error al crear el centro:", error);
        errorMessage.textContent = "Error al crear el centro. Intenta de nuevo.";
        errorMessage.style.display = "block";
    }
});


// Cargar los centros
async function loadCenters() {
    centersList.innerHTML = "";
    const querySnapshot = await getDocs(collection(db, "centers"));
    querySnapshot.forEach((docSnap) => {
        const center = docSnap.data();
        const centerId = docSnap.id;
        const pets = Array.isArray(center.pets) ? center.pets : [];

        const centerCard = document.createElement("div");
        centerCard.className = "center-card";

        centerCard.innerHTML = `
            <h3>${center.name}</h3>
            <p><strong>Ubicación:</strong> ${center.location}</p>
            <p><strong>Contacto:</strong> ${center.contact}</p>
            <p><strong>Sobre nosotros:</strong>${center.description}</p>
            <h4>Mascotas:</h4>
            
                ${
                    pets.length > 0
                        ? pets.map((pet) => `
                            <li>
                                <strong>${pet.name}</strong>: ${pet.description}
                                ${pet.photo ? `<br><img src="${pet.photo}" alt="Foto de ${pet.name}" style="width: 100px; height: auto; margin-top: 10px;">` : ""}
                            </li>
                        `).join("")
                        : "<li>Sin mascotas disponibles</li>"
                }
            
            <button class="form-button edit-button" data-id="${centerId}">Editar</button>
            <button class="form-button delete-button" data-id="${centerId}">Eliminar</button>
        `;

        centersList.appendChild(centerCard);
    });

    attachDeleteEvents();
    attachEditEvents();
}



// Función para eliminar centros
function attachDeleteEvents() {
    const deleteButtons = document.querySelectorAll(".delete-button");
    deleteButtons.forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const id = e.target.dataset.id;
            try {
                await deleteDoc(doc(db, "centers", id));
                loadCenters();
            } catch (error) {
                console.error("Error al eliminar el centro:", error);
            }
        });
    });
}

// Función para editar centros
function attachEditEvents() {
    const editButtons = document.querySelectorAll(".edit-button");
    editButtons.forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const id = e.target.dataset.id;
            const centerDoc = doc(db, "centers", id);
            const centerSnap = await getDoc(centerDoc);

            if (centerSnap.exists()) {
                const center = centerSnap.data();
                document.getElementById("edit-name").value = center.name;
                document.getElementById("edit-location").value = center.location;
                document.getElementById("edit-contact").value = center.contact;
                document.getElementById("edit-description").value = center.description;

                // Cargar mascotas en el modal
                const petsContainer = document.getElementById("edit-pets-container");
                petsContainer.innerHTML = `
                    <h3>Mascotas Disponibles</h3>
                    <button type="button" id="add-edit-pet" class="form-button">Agregar Mascota</button>
                    <div id="edit-pets-list"></div>
                `;

                const petsList = petsContainer.querySelector("#edit-pets-list");

                if (center.pets && center.pets.length > 0) {
                    center.pets.forEach((pet) => {
                        const petForm = document.createElement("div");
                        petForm.className = "pet-form";

                        petForm.innerHTML = `
                            <label class="form-label">Nombre de la Mascota:</label>
                            <input type="text" class="form-input pet-name" value="${pet.name}" required>

                            <label class="form-label">Descripción:</label>
                            <textarea class="form-textarea pet-description" rows="2">${pet.description}</textarea>

                            <label class="form-label">Foto de la Mascota:</label>
                            <input type="file" class="form-input pet-photo" accept="image/*">
                            ${pet.photo ? `<img src="${pet.photo}" alt="Foto de ${pet.name}" style="width: 100px; height: auto; margin-top: 10px;">` : ""}
                            
                            <button type="button" class="form-button delete-pet">Eliminar Mascota</button>
                        `;

                        petsList.appendChild(petForm);

                        // Agregar funcionalidad para eliminar mascota
                        petForm.querySelector(".delete-pet").addEventListener("click", () => {
                            petsList.removeChild(petForm);
                        });
                    });
                } else {
                    // No agregar texto en el modal si no hay mascotas
                    petsList.innerHTML = ``;
                }

                // Asignar evento al botón "Agregar Mascota"
                const addEditPetButton = document.getElementById("add-edit-pet");
                addEditPetButton.addEventListener("click", () => {
                    const petForm = document.createElement("div");
                    petForm.className = "pet-form";

                    petForm.innerHTML = `
                        <label class="form-label">Nombre de la Mascota:</label>
                        <input type="text" class="form-input pet-name" placeholder="Ej. Fido" required>

                        <label class="form-label">Descripción:</label>
                        <textarea class="form-textarea pet-description" placeholder="Descripción de la mascota" rows="2"></textarea>

                        <label class="form-label">Foto de la Mascota:</label>
                        <input type="file" class="form-input pet-photo" accept="image/*">

                        <button type="button" class="form-button delete-pet">Eliminar Mascota</button>
                    `;

                    petsList.appendChild(petForm);

                    // Agregar funcionalidad para eliminar mascota
                    petForm.querySelector(".delete-pet").addEventListener("click", () => {
                        petsList.removeChild(petForm);
                    });
                });

                // Mostrar el modal de edición
                editModal.style.display = "block";

                // Guardar cambios en el formulario
                editForm.onsubmit = async (e) => {
                    e.preventDefault();

                    const updatedPets = [];
                    const petForms = document.querySelectorAll("#edit-pets-container .pet-form");

                    for (const petForm of petForms) {
                        const petName = petForm.querySelector(".pet-name").value;
                        const petDescription = petForm.querySelector(".pet-description").value;
                        const petPhoto = petForm.querySelector(".pet-photo")?.files[0];

                        let photoURL = petForm.querySelector("img")?.src || null;

                        if (petPhoto) {
                            const photoRef = ref(storage, `pets/${Date.now()}_${petPhoto.name}`);
                            await uploadBytes(photoRef, petPhoto);
                            photoURL = await getDownloadURL(photoRef);
                        }

                        updatedPets.push({ name: petName, description: petDescription, photo: photoURL });
                    }

                    try {
                        await updateDoc(centerDoc, {
                            name: document.getElementById("edit-name").value,
                            location: document.getElementById("edit-location").value,
                            contact: document.getElementById("edit-contact").value,
                            description: document.getElementById("edit-description").value,
                            pets: updatedPets,
                        });

                        editModal.style.display = "none";
                        loadCenters();
                    } catch (error) {
                        console.error("Error al actualizar el centro:", error);
                    }
                };
            }
        });
    });
}




// Cerrar el modal
closeModal.addEventListener("click", () => {
    editModal.style.display = "none";
});

// Cargar los centros al inicio
loadCenters();
