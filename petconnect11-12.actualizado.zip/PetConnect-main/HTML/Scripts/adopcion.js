import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, collection, getDocs } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const centersGrid = document.getElementById("centers-grid");

// Obtener los centros desde Firestore
async function fetchCenters() {
    const querySnapshot = await getDocs(collection(db, "centers"));
    querySnapshot.forEach((doc) => {
        const center = doc.data();
        const centerId = doc.id; // Obtener el ID del documento
        const centerCard = document.createElement("div");
        centerCard.className = "center-card";

        centerCard.innerHTML = `
            <h3>${center.name}</h3>
            <p><strong>Ubicación:</strong> ${center.location}</p>
            <p><strong>Contacto:</strong> ${center.contact}</p>
            <p><strong>Sobre nosotros:</strong>${center.description}</p>
            <button class="form-button view-availability" data-id="${centerId}">Ver Mascotas</button>
        `;

        centersGrid.appendChild(centerCard);

        // Agregar evento al botón "Ver Disponibilidad"
        centerCard.querySelector(".view-availability").addEventListener("click", () => {
            window.location.href = `disponibilidad.html?centerId=${centerId}`;
        });
    });
}

fetchCenters();
