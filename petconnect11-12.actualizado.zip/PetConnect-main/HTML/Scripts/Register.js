import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, updateProfile } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";
import { getFirestore, collection, addDoc, doc, setDoc } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js";

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Escuchar el formulario de registro
document.getElementById("register-form").addEventListener("submit", async function (e) {
    e.preventDefault();

    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value; // Captura el rol seleccionado
    const errorMessage = document.getElementById("error-message");

    try {
        errorMessage.style.display = "none";
        errorMessage.textContent = "";

        // Crear usuario con Firebase Authentication
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;

        // Actualizar el perfil del usuario
        await updateProfile(user, { displayName: username });

        // Guardar datos adicionales en Firestore
        const userRef = doc(db, "users", user.uid); // Crear un documento con el UID del usuario
        await setDoc(userRef, {
            uid: user.uid,
            username: username,
            email: email,
            role: role // Guarda el rol en la base de datos
        });

        // Mensaje de éxito
        alert("Registro exitoso. ¡Bienvenido, " + username + "!");
        window.location.href = "index.html"; // Redirigir a la página de inicio
        document.getElementById("register-form").reset();

    } catch (error) {
        if (error.code === "auth/email-already-in-use") {
            errorMessage.textContent = "El correo ingresado ya está en uso. Por favor, usa otro correo o inicia sesión.";
        } else if (error.code === "auth/invalid-email") {
            errorMessage.textContent = "Por favor, ingresa un correo electrónico válido.";
        } else if (error.code === "auth/weak-password") {
            errorMessage.textContent = "La contraseña es demasiado débil. Debe tener al menos 8 caracteres alfanuméricos.";
        } else {
            errorMessage.textContent = "Ocurrió un error. Por favor, intenta de nuevo.";
        }
        errorMessage.style.display = "block";
        console.error("Error: ", error);
    }
});
