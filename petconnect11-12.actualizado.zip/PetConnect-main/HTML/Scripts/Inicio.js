import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";


        // Configuración de Firebase
        const firebaseConfig = {
            apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
            authDomain: "petconnect-992db.firebaseapp.com",
            projectId: "petconnect-992db",
            storageBucket: "petconnect-992db.appspot.com",
            messagingSenderId: "175930672807",
            appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
            measurementId: "G-E09LD3T7QC"
        };

        // Inicializar Firebase
        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);

        // Manejo del formulario de inicio de sesión
        const loginForm = document.getElementById("login-form");
        loginForm.addEventListener("submit", async function (e) {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const errorMessage = document.getElementById("error-message");

            try {
                // Ocultar mensajes de error previos
                errorMessage.style.display = "none";
                errorMessage.textContent = "";

                // Intentar iniciar sesión
                const userCredential = await signInWithEmailAndPassword(auth, email, password);
                const user = userCredential.user;

                // Redirigir al usuario después del inicio de sesión exitoso
                alert("Inicio de sesión exitoso. ¡Bienvenido de nuevo, " + user.email + "!");
                window.location.href = "index.html"; // Redirigir a la página de inicio
            } catch (error) {
                // Mostrar mensajes de error basados en el código de error
                if (error.code === "auth/user-not-found") {
                    errorMessage.textContent = "No se encontró una cuenta con este correo. Verifica tus datos o regístrate.";
                } else if (error.code === "auth/wrong-password") {
                    errorMessage.textContent = "La contraseña ingresada es incorrecta. Intenta de nuevo.";
                } else if (error.code === "auth/invalid-email") {
                    errorMessage.textContent = "Por favor, ingresa un correo electrónico válido.";
                } else {
                    errorMessage.textContent = "Ocurrió un error. Por favor, intenta de nuevo.";
                }
                errorMessage.style.display = "block";
                console.error("Error al iniciar sesión: ", error);
            }
        });