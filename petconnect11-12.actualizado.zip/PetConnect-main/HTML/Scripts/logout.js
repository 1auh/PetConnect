import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getAuth, onAuthStateChanged, signOut } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js';

  // Configuración de Firebase
  const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
  };

  // Inicializar Firebase
  const app = initializeApp(firebaseConfig);
  const auth = getAuth(app);

  // Referencia al botón de sesión
  const sessionBtn = document.querySelector('.session-btn');

  // Escuchar cambios en el estado de autenticación
  onAuthStateChanged(auth, (user) => {
    if (user) {
      // Si el usuario está autenticado, muestra el botón como "Logout"
      sessionBtn.textContent = "Logout";
      sessionBtn.style.display = "block";

      // Configura el botón para cerrar sesión
      sessionBtn.addEventListener("click", async (e) => {
        e.preventDefault();
        await signOut(auth);
        window.location.href = "registro.html"; // Redirige al formulario de registro
      });
    } else {
      // Si no hay usuario autenticado, muestra el botón como "Registro / Log In"
      sessionBtn.textContent = "Registro / Log In";
      sessionBtn.style.display = "block";
      sessionBtn.href = "registro.html"; // Redirige a la página de registro/login
    }
  });