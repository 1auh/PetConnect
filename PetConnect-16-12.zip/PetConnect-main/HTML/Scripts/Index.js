import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, doc, getDoc, collection, getDocs } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const reportsGrid = document.getElementById("index-reports-grid");

// Función para cargar los reportes (disponible para todos los usuarios)
async function loadReports() {
    const querySnapshot = await getDocs(collection(db, "reports"));
    reportsGrid.innerHTML = ""; // Limpiar el contenedor antes de recargar

    querySnapshot.forEach((docSnap) => {
        const report = docSnap.data();

        const reportCard = document.createElement("div");
        reportCard.className = "report-card";

        reportCard.innerHTML = `
            <h3>${report.name}</h3>
            ${report.photo ? `<img src="${report.photo}" alt="Foto de ${report.name}" class="report-photo">` : ""}
            <p><strong>Descripción:</strong> ${report.description}</p>
            <p><strong>Zona:</strong> ${report.zone}</p>
            <p><strong>Contacto:</strong> ${report.contact}</p>
        `;

        reportsGrid.appendChild(reportCard);
    });
}

// Verificar el estado de autenticación del usuario
onAuthStateChanged(auth, async (user) => {
    if (user) {
        // Mostrar reportes para todos los usuarios autenticados
        loadReports();

        const userDocRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);

        if (userDoc.exists()) {
            const userData = userDoc.data();

            if (userData.role === 'admin') {
                // Mostrar el botón "Crear Centros" si el usuario es administrador
                const adminLinks = document.querySelectorAll('.admin-only');
                adminLinks.forEach(link => {
                    link.style.display = 'block';
                });
            }
        }
    } else {
        console.log("Usuario no autenticado.");
        reportsGrid.innerHTML = `<p class="centered-message">Inicia sesión para ver los reportes.</p>`;

    }
});
