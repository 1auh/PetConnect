import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, doc, getDoc } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const petsGrid = document.getElementById("pets-grid");

// Obtener el `centerId` de la URL
const urlParams = new URLSearchParams(window.location.search);
const centerId = urlParams.get("centerId");

// Verifica que el ID del centro exista
if (!centerId) {
    petsGrid.innerHTML = `<p>Error: No se proporcionó un ID de centro.</p>`;
} else {
    fetchCenterPets(centerId);
}

// Función para obtener mascotas del centro
async function fetchCenterPets(centerId) {
    try {
        const centerDoc = doc(db, "centers", centerId);
        const centerSnap = await getDoc(centerDoc);

        if (!centerSnap.exists()) {
            petsGrid.innerHTML = `<p>Error: Centro no encontrado.</p>`;
            return;
        }

        const center = centerSnap.data();
        const pets = center.pets || [];

        if (pets.length === 0) {
            petsGrid.innerHTML = `<p class="centered-message">No hay mascotas disponibles en este centro</p>`;
            return;
        }

        pets.forEach((pet) => {
            const petCard = document.createElement("div");
            petCard.className = "pet-card";
        
            petCard.innerHTML = `
                <img src="${pet.photo || '/images/default-pet.jpg'}" alt="Foto de ${pet.name}">
                <h3>${pet.name}</h3>
                <p><strong>Descripcion:</strong>${pet.description}</p>
            `;
        
            petsGrid.appendChild(petCard);
        });
        
    } catch (error) {
        console.error("Error al obtener mascotas:", error);
        petsGrid.innerHTML = `<p>Error al cargar las mascotas. Intenta de nuevo más tarde.</p>`;
    }
}
