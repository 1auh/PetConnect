import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, collection, getDocs } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

const centersGrid = document.getElementById("centers-grid");

// Obtener los centros desde Firestore
async function fetchCenters() {
    centersGrid.innerHTML = ""; // Limpiar el contenedor antes de recargar
    const querySnapshot = await getDocs(collection(db, "centers"));

    if (querySnapshot.empty) {
        // Si no hay centros, mostrar mensaje
        centersGrid.innerHTML = `<p class="centered-message">No hay centros disponibles en este momento.</p>`;
        return;
    }

    querySnapshot.forEach((doc) => {
        const center = doc.data();
        const centerId = doc.id; // Obtener el ID del documento
        const centerCard = document.createElement("div");
        centerCard.className = "center-card";

        centerCard.innerHTML = `
            <h3>${center.name}</h3>
            <p><strong>Ubicación:</strong> ${center.location}</p>
            <p><strong>Contacto:</strong> ${center.contact}</p>
            <p><strong>Sobre nosotros:</strong>${center.description}</p>
            <button class="form-button view-availability" data-id="${centerId}">Ver Mascotas</button>
        `;

        centersGrid.appendChild(centerCard);

        // Agregar evento al botón "Ver Disponibilidad"
        centerCard.querySelector(".view-availability").addEventListener("click", () => {
            window.location.href = `disponibilidad.html?centerId=${centerId}`;
        });
    });
}

// Verificar el estado de autenticación del usuario
onAuthStateChanged(auth, (user) => {
    if (user) {
        // Si el usuario está autenticado, cargar los centros
        fetchCenters();
    } else {
        // Si el usuario no está autenticado, mostrar mensaje y bloquear acceso
        centersGrid.innerHTML = `<p class="centered-message">Inicia sesión para ver los centros de adopción.</p>`;
    }
});

