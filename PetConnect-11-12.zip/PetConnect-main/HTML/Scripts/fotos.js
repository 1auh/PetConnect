import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js';
import { getFirestore, collection, addDoc } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/9.22.2/firebase-storage.js';

// Configuración de Firebase
const firebaseConfig = {
    apiKey: "AIzaSyDIk3Jx7VUbUpH5_CMvxKb2OB-A3eEfCHA",
    authDomain: "petconnect-992db.firebaseapp.com",
    projectId: "petconnect-992db",
    storageBucket: "petconnect-992db.appspot.com",
    messagingSenderId: "175930672807",
    appId: "1:175930672807:web:49bffbae4f0e878b1fd82",
    measurementId: "G-E09LD3T7QC"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

const form = document.getElementById("create-center-form");
const successMessage = document.getElementById("success-message");
const errorMessage = document.getElementById("error-message");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const location = document.getElementById("location").value;
    const contact = document.getElementById("contact").value;
    const pets = document.getElementById("pets").value;
    const description = document.getElementById("description").value;
    const photoFiles = document.getElementById("photo").files;

    try {
        // Subir fotos a Firebase Storage
        const photoURLs = [];
        for (let i = 0; i < photoFiles.length; i++) {
            const photoRef = ref(storage, `centros/${name}/${photoFiles[i].name}`);
            await uploadBytes(photoRef, photoFiles[i]);
            const photoURL = await getDownloadURL(photoRef);
            photoURLs.push(photoURL);
        }

        // Guardar datos en Firestore
        await addDoc(collection(db, "centers"), {
            name,
            location,
            contact,
            pets: parseInt(pets),
            description,
            photos: photoURLs,
        });

        successMessage.style.display = "block";
        errorMessage.style.display = "none";
        form.reset();
    } catch (error) {
        errorMessage.textContent = "Error al crear el centro. Intenta de nuevo.";
        errorMessage.style.display = "block";
        successMessage.style.display = "none";
        console.error("Error: ", error);
    }
});
